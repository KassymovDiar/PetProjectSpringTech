package com.adamantsystems.adamantecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdamantEcommerceApplicationTests {

    @Test
    void contextLoads() {
    }

}
